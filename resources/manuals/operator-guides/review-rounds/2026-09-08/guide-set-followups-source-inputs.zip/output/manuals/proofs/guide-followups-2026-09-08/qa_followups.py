from pathlib import Path
import json, re, difflib, hashlib
import pdfplumber
from PIL import Image, ImageDraw

repo = Path('C:/dev/snipe-it-fork')
root = repo / 'output/manuals/proofs/guide-followups-2026-09-08'
frozen = repo / 'resources/manuals/operator-guides/checkpoints/2026-09-08-before-audit-revisions'
manifest = json.loads((frozen / 'manifest.json').read_text(encoding='utf-8-sig'))
records = []
cached = {r['code']: r for r in json.loads((root/'qa-summary.json').read_text(encoding='utf-8'))} if (root/'qa-summary.json').exists() else {}
for validation in sorted(root.glob('*-v*/validation.json')):
    record = json.loads(validation.read_text())
    if cached.get(record['code'],{}).get('sha256') == record['sha256']:
        record['comparison'] = cached[record['code']]['comparison']
        records.append(record)
        continue
    matches = [a for a in manifest['artifacts'] if a['code'] == record['code'] and a['version'] == record['baselineVersion']]
    assert matches, record['code']
    baseline = matches[-1]
    with pdfplumber.open(frozen / baseline['checkpointPath']) as old, pdfplumber.open(repo / 'output/pdf' / record['file']) as new:
        assert len(old.pages) == len(new.pages) == record['pages'], record['code']
        pages=[]
        for index, (before, after) in enumerate(zip(old.pages,new.pages),1):
            btext=before.extract_text() or ''
            atext=after.extract_text() or ''
            normalize=lambda t: re.sub(r'2026-\d\d-\d\d|\bv\d+\b','VERSION',t)
            diff='\n'.join(difflib.unified_diff(normalize(btext).splitlines(),normalize(atext).splitlines(),fromfile='baseline',tofile='candidate',lineterm=''))
            (validation.parent/f'text-diff-page-{index}.txt').write_text(diff,encoding='utf-8')
            bboxes=lambda p: [[round(im[k],2) for k in ('x0','top','x1','bottom')] for im in p.images]
            outside=[c['text'] for c in after.chars if c['x0'] < -0.1 or c['x1'] > after.width+0.1 or c['top'] < -0.1 or c['bottom'] > after.height+0.1]
            pages.append({'page':index,'oldImages':len(before.images),'newImages':len(after.images),'oldImageBoxes':bboxes(before),'newImageBoxes':bboxes(after),'oldTextLines':len(btext.splitlines()),'newTextLines':len(atext.splitlines()),'outsideCharacters':outside,'oldHelpHeadings':re.findall(r'^Hulp.*$',btext,re.M),'newHelpHeadings':re.findall(r'^Hulp.*$',atext,re.M)})
            assert not outside, (record['code'],index,outside)
            assert len(before.images)==len(after.images),(record['code'],index,len(before.images),len(after.images))
            # Compare page anatomy; all source-image changes are reviewed separately.
            assert pages[-1]['oldHelpHeadings']==pages[-1]['newHelpHeadings'], (record['code'], index, 'help removed')
    record['comparison']={'baseline':baseline,'pages':pages}
    records.append(record)

(root/'qa-summary.json').write_text(json.dumps(records,indent=2,ensure_ascii=False),encoding='utf-8')
images=[]
for record in records:
    for index in range(1,record['pages']+1):
        images.append((f"{record['code']} v{record['version']} / {index}", root/f"{record['code']}-v{record['version']}"/record['file'].replace('.pdf',f'-{index}.png')))
for i in range(0,len(images),2):
    sheet=Image.new('RGB',(1680,1229),'#dddddd')
    draw=ImageDraw.Draw(sheet)
    for col,(label,file) in enumerate(images[i:i+2]):
        im=Image.open(file).convert('RGB'); im.thumbnail((830,1194))
        sheet.paste(im,(col*840+5,30))
        draw.text((col*840+12,8),label,fill='black')
    sheet.save(root/f'qa-sheet-{i//2+1:02}.png')
print(json.dumps({'guides':len(records),'pages':len(images),'images':sum(p['newImages'] for r in records for p in r['comparison']['pages']),'sheets':(len(images)+1)//2}))
