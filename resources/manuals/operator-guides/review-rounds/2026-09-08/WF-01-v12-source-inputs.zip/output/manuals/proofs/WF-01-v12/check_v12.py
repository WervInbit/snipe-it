from pathlib import Path
import json
import hashlib
from PIL import Image, ImageChops, ImageDraw
from pypdf import PdfReader
import pdfplumber
root=Path.cwd()
proof=root/'output/manuals/proofs/WF-01-v12'
new=root/'output/pdf/WF-01-workflow-starten-v12-draft.pdf'
old=root/'resources/manuals/operator-guides/checkpoints/2026-09-08-before-audit-revisions/drafts/WF-01-start-workflow-v10-draft.pdf'
baseline=proof/'baseline/WF-01-start-workflow-v10-draft-proof.pdf'
r=PdfReader(new)
assert len(r.pages)==1 and not r.is_encrypted
page=r.pages[0]
assert abs(float(page.mediabox.width)-595.28)<1 and abs(float(page.mediabox.height)-841.89)<1
text=' '.join(page.extract_text().split())
old_text=' '.join(PdfReader(old).pages[0].extract_text().split())
original_lines=PdfReader(old).pages[0].extract_text().splitlines()
missing=[]
for line in original_lines:
    line=' '.join(line.split()).replace('Draft v10','Draft v12').replace('2026-08-18','2026-09-08')
    if line and line not in text: missing.append(line)
assert not missing, missing
for item in ['1A','2A','3A','3B','4A','Geen test-icoon','Run onduidelijk','Verkeerd profiel','Geen kaarten','Klaar als','Kies 3A of 3B. Voer maar een optie uit.']:
    assert item in text,item
assert 'dev.inbit' not in text and 'Draft v11' not in text
old_img=Image.open(proof/'frozen-v10-1.png').convert('RGB')
base_img=Image.open(proof/'baseline/WF-01-start-workflow-v10-draft-proof.png').convert('RGB')
new_img=Image.open(proof/'WF-01-workflow-starten-v12-draft-1.png').convert('RGB')
assert old_img.size==base_img.size==new_img.size
base_diff=ImageChops.difference(old_img,base_img)
changed=ImageChops.difference(base_img,new_img)
validation=json.loads((proof/'validation.json').read_text())
mask=Image.new('L',new_img.size,0)
draw=ImageDraw.Draw(mask)
step=validation['step3ContentBounds']['step']
scale=1.5
regions=[(64,589,591,1264),(925,65,1125,194),(64,1604,670,1622)]
for box in regions: draw.rectangle(tuple(map(int,box)),fill=255)
outside=Image.composite(Image.new('RGB',new_img.size,0),changed,mask)
assert base_diff.getbbox() is None, 'Baseline reproduction differs from frozen v10'
assert outside.getbbox() is None, 'Unexpected changes outside step 3 and version/date'
print(json.dumps({'pages':len(r.pages),'bytes':new.stat().st_size,'sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'originalTextLinesRetained':len(original_lines),'baselineReproductionDiffBounds':base_diff.getbbox(),'changesOutsideStep3VersionDate':outside.getbbox(),'imageSize':new_img.size},indent=2))
changed.save(proof/'v10-v12-difference.png')
outside.save(proof/'unexpected-difference.png')
validation['pdfValidation']={'pages':1,'a4':True,'unencrypted':True,'originalTextLinesRetained':len(original_lines),'noDevelopmentUrl':True}
validation['rasterComparison']={'baselineReproductionDiffBounds':base_diff.getbbox(),'changesOutsideStep3VersionDate':outside.getbbox(),'pixelDimensions':new_img.size}
(proof/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
(proof/'v12-text.txt').write_text(page.extract_text(),encoding='utf-8')
