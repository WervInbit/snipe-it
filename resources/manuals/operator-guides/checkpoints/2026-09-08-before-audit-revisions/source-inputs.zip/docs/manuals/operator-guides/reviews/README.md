# Operator Guide Review Records

Focused review records preserve the small corrections made while a guide is
iterated. They complement guide specifications; they do not replace them.

## Current Set Audit

- [2026-09-08 independent usability and consistency audit](2026-09-08-independent-usability-audit.md):
  all 22 current generated guides / 48 pages, shared rules, high-risk local
  application behavior, and missing guide dependencies. Records 22 findings
  and a proposed correction order; no artifact acceptance changed.
- [Exact audit evidence](2026-09-08-audit-evidence.json): PDF versions, hashes,
  page counts, measured type sizes, validation outcomes, and limitations.

## Version Reviews

Create one file per reviewed version using `<CODE>-vN.md` and record:

- artifact status;
- source version and output paths;
- accepted content and visual corrections;
- open corrections or evidence gaps;
- feedback promoted to a guide, family, or global rule;
- feedback source and impact classification;
- previous version and complete affected-guide list for shared changes;
- layout recipe and step-pattern changes;
- PDF, page-count, text, geometry, and visual QA results.

When the next version is created, retain the previous record. Do not rewrite
history to make an older artifact appear compliant with a newer rule.

Use [maintenance.md](../maintenance.md) for the full change workflow. A global,
family, recipe, evidence, or policy change requires a review record for every
visibly affected guide version, not only the first representative proof.
